//
//  ViewController.swift
//  JD Sports
//
//  Created by Orbysol on 1/19/18.
//  Copyright © 2018 Orbysol. All rights reserved.
//

import UIKit

let MenuViewCellIdentifier = "MenuViewCellIdentifier"
let urlString = "https://uat.jdgroupmeshtest.cloud/stores/jdsports/nav?api_key=56E94850997111E3A5E20800200C9A66"

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableViewLeadingSpaceConstraint: NSLayoutConstraint!
    
    var tableData = [String]()
    var isMenuVisible = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dropShadow()
        registerNibs()
        getDataAndReload()
    }
    
    func registerNibs() {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: MenuViewCellIdentifier)
    }
    
    func dropShadow() {
        tableView.layer.masksToBounds = false
        tableView.layer.shadowColor = UIColor.black.withAlphaComponent(0.7).cgColor
        tableView.layer.shadowOpacity = 0.4
        tableView.layer.shadowOffset = CGSize(width: 0, height: 0)
        tableView.layer.shadowRadius = 3.0
    }
    
    func getDataAndReload() {
        let config = URLSessionConfiguration.default
        config.httpAdditionalHeaders = ["Content-Type": "application/json"]
        config.httpAdditionalHeaders = ["Accept": "application/json"]
        let session = URLSession(configuration: config)
        
        let url = URL.init(string: urlString)
        let urlRequest = NSMutableURLRequest.init(url: url!)
        urlRequest.httpMethod = "GET"
        
        let task = session.dataTask(with: urlRequest as URLRequest) {
            (data, response, error) -> Void in
            
            if let data = data {
                do {
                    if let jsonResult = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String : Any] {
                        let navItems = jsonResult["nav"] as! [[String : Any]]
                        self.tableData = navItems.map { $0["navigationName"] as! String }
                        
                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                        }
                    }
                } catch let error as NSError {
                    print(error.localizedDescription)
                }
            } else if let error = error {
                print(error.localizedDescription)
            }
        }
        task.resume()
        
    }

    @IBAction func menuButtonTapped(_ sender: UIBarButtonItem) {
        if isMenuVisible {
            tableViewLeadingSpaceConstraint.constant = -200.0
            isMenuVisible = false
        } else {
            tableViewLeadingSpaceConstraint.constant = 0
            isMenuVisible = true
        }
        UIView.animate(withDuration: 0.22, delay: 0.0, options: [.curveEaseIn], animations: {
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MenuViewCellIdentifier)!
        cell.textLabel?.text = tableData[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableViewLeadingSpaceConstraint.constant = -200.0
        isMenuVisible = false
        UIView.animate(withDuration: 0.22, delay: 0.0, options: [.curveEaseIn], animations: {
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
}

